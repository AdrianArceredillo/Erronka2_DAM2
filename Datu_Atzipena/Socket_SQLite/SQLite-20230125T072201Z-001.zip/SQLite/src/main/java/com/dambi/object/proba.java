package com.dambi.object;

public class proba {
    public static void main(String[] args) {
        String str = "1234567890";
        str = str.substring(0, str.length() - 2);
        System.out.println(str);

    }
    
}
